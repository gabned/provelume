# Local verification notes

Local command adaptation errors were corrected without changing candidate, release, gates or runtime:
- Offline report import first used the system interpreter without Core/dependencies; the accepted .venv interpreter and Core/script paths then replayed the original report, preserving FAIL 26/27 and Linux PASS 27/27.
- Readiness parser requires decoded JSON rather than raw bytes; the corrected accepted validator passed on the original downloaded bytes.
- The legacy effects CLI takes one path per line, not a JSON array; the invalid local-input result remains in effects-invalid-local-input.json, and the corrected eight-path result is current-effects.json. Neither creates a new binding.
- CI normalization used a nonexistent timestamp helper, then incorrect source/UTC formatting; corrected input uses GITHUB_CONNECTOR and the original observation timestamp in the accepted Z format. Complete inventory validation succeeds; success validation correctly rejects the failed applicable workflow.
- Diagnostic reducer initially used a zip with mismatched lengths; corrected point pairs reconcile all 60 first-wall measurements. No native execution was repeated for this script error.

These are local collector/verification input errors, separate from candidate/native failures. The first diagnostic observer's Windows clock granularity was itself demonstrated by spans that collapse to zero; the second observer adds QPC and a supervisor dequeue point while preserving the first observation and original contractual timing.

Local observer validation (Linux, Python 3.12.14): first observer 679a43dd8d4ecac70c36af781b92134f11317732 Ruff PASS / 2 tests PASS (0.17 s); QPC observer b1d3259538e2b75ac01a36d18e1c8bee1d84988d Ruff PASS / 2 tests PASS (0.12 s). git diff --check PASS for both. These test observer transparency using synthetic functions; they load no GGUF and do not qualify an AI runtime.

