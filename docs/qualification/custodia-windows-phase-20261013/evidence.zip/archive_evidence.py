"""Preserve bytes; this archive is evidence, never an official installation kit."""
from pathlib import Path
import hashlib,json,zipfile
p=Path(__file__).parent
allfiles=[]
for f in p.rglob('*'):
 if not f.is_file(): continue
 rel=f.relative_to(p)
 if any(part in {'bundle-components','bundle-restore-check'} for part in rel.parts): continue
 if f.suffix=='.bundle' and f.name!='source-history-diagnostic-final.bundle': continue
 allfiles.append((rel.as_posix(),f))
allfiles.sort()
for scope in ['full','compact']:
 files=[(n,f) for n,f in allfiles if scope=='full' or f.stat().st_size<=8*1024**2 or f.suffix=='.bundle']
 manifest={'scope':scope,'purpose':'EVIDENCE_ONLY_NOT_INSTALLATION_KIT','files':[
  {'path':n,'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in files],
  'excluded_large_payloads':[{'path':n,'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in allfiles if (n,f) not in files]}
 output=p.parent/f'provelume-0.12.1-closure-20261013-{scope}-evidence.zip'
 with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,f in files: z.write(f,n)
  z.writestr('EVIDENCE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(output) as z:
  assert z.testzip() is None
  restored=p.parent/f'closure-20261013-{scope}-restore'
  restored.mkdir(exist_ok=True)
  z.extractall(restored)
  for row in manifest['files']:
   f=restored/row['path']
   assert f.stat().st_size==row['size_bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256']
 print(json.dumps({'scope':scope,'path':str(output),'files':len(files)+1,'size_bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'byte_restoration':'PASS'}))

