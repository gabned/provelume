import hashlib,json,subprocess,concurrent.futures
from pathlib import Path
p=Path('/workspace/provelume/.agent/closure-0.12.1-20261013')
a=json.loads((p/'release.json').read_text())['assets']
d=p/'public-assets';d.mkdir(exist_ok=True)
def get(a):
 if a['size']>32*1024**2: return {'name':a['name'],'status':'NOT_DOWNLOADED_OVER_32_MIB','size':a['size']}
 f=d/a['name']
 r=subprocess.run(['curl','--silent','--show-error','--fail','--location','--max-time','60','--max-filesize',str(32*1024**2),'-o',str(f),a['browser_download_url']],capture_output=True,text=True)
 if r.returncode: return {'name':a['name'],'status':'TRANSPORT_ERROR','code':r.returncode,'error':r.stderr}
 h='sha256:'+hashlib.sha256(f.read_bytes()).hexdigest()
 return {'name':a['name'],'size':f.stat().st_size,'digest':h,'status':'PASS' if h==a['digest'] and f.stat().st_size==a['size'] else 'MISMATCH'}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool: rows=list(pool.map(get,a))
(p/'fresh-downloads.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'pass':sum(x['status']=='PASS' for x in rows),'other':[x for x in rows if x['status']!='PASS']}))

