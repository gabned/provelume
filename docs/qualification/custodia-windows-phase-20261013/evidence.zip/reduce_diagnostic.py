"""Reduce the diagnostic trace by request/PID; never evaluate qualification."""
from pathlib import Path
import json
import sys
p=Path(__file__).parent
root=p/(sys.argv[1] if len(sys.argv)>1 else 'diagnostic')
report=json.loads(next(root.rglob('diagnostic.json')).read_text())
parent=[json.loads(line) for line in next(root.rglob('parent.jsonl')).read_text().splitlines()]
workers=[json.loads(line) for file in root.rglob('worker-*.jsonl') for line in file.read_text().splitlines()]
def wall(r): return (r['end']['wall_ns']-r['start']['wall_ns'])/1e9
def cpu(r): return (r['end']['cpu_ns']-r['start']['cpu_ns'])/1e9
def precise(r):
 return (r['end']['performance_ns']-r['start']['performance_ns'])/1e9
rows=[]
for sample in report['samples']:
 request=sample['prefill']['request'];pid=sample['prefill']['pid']
 pr=[r for r in parent if r['sample']==f"run{sample['run']}/{sample['id']}"]
 wr=[r for r in workers if r['request']==request and r['start']['pid']==pid]
 def one(values,phase):
  hits=[r for r in values if r['phase']==phase]
  assert len(hits)==1,(sample['id'],sample['run'],phase,len(hits))
  return hits[0]
 q=one([r for r in pr if r['request']==request],'parent.qualify')
 infer=one([r for r in pr if r['request']==request],'parent.infer')
 owned=one([r for r in pr if r['request']==request],'parent.infer_owned')
 send=one([r for r in pr if r['request']==request],'parent.send')
 adm=one([r for r in pr if q['start']['wall_ns']<=r['start']['wall_ns'] and r['end']['wall_ns']<=infer['start']['wall_ns']],'admission.store_use')
 verify=one([r for r in pr if adm['start']['wall_ns']<=r['start']['wall_ns'] and r['end']['wall_ns']<=adm['end']['wall_ns']],'gguf.verify_stream')
 runtime=[r for r in pr if r['phase']=='runtime.validate_installation' and q['start']['wall_ns']<=r['start']['wall_ns'] and r['end']['wall_ns']<=send['start']['wall_ns']]
 read=one(wr,'worker.request_read');gen=one(wr,'native.generate')
 prefill=one(wr,'worker.emit.prefill');first=one(wr,'worker.emit.first')
 decode=[r for r in wr if r['phase']=='native.prefill_decode']
 queue=one([r for r in pr if r['request']==request],'reader.queue.first')
 received=one([r for r in pr if r['request']==request],'parent.receive.result')
 points=[q['start']['wall_ns'],adm['start']['wall_ns'],adm['end']['wall_ns'],infer['start']['wall_ns'],owned['start']['wall_ns'],send['start']['wall_ns'],read['start']['wall_ns'],gen['start']['wall_ns'],prefill['start']['wall_ns'],first['start']['wall_ns'],queue['start']['wall_ns'],round(received['first_received']*1e9)]
 keys=['qualify_entry','store_admission','admission_to_infer','request_lock','parent_validation','send_to_worker_read','worker_validation','tokenize_reset','prefill_to_first_emit','emit_to_reader_queue','queue_to_supervisor_first']
 partition={key:(b-a)/1e9 for key,a,b in zip(keys,points[:-1],points[1:],strict=True)}
 assert all(v>=-1e-6 for v in partition.values()),partition
 reconstructed=(points[-1]-points[0])/1e9
 assert abs(reconstructed-sample['first_wall_seconds'])<0.02
 row={'case':sample['id'],'run':sample['run'],'request':request,'worker_pid':pid,
  'first_wall_seconds':sample['first_wall_seconds'],'native_first_seconds':sample['first_seconds'],
  'admission_seconds':wall(adm),'gguf_seconds':wall(verify),'gguf_cpu_seconds':cpu(verify),
  'runtime_check_seconds':sum(wall(x) for x in runtime),
  'native_prefill_decode_seconds':sum(wall(x) for x in decode),
  'native_prefill_decode_cpu_seconds':sum(cpu(x) for x in decode),
  'partition':partition,'reconstructed_first_seconds':reconstructed,
  'measurement_difference_seconds':reconstructed-sample['first_wall_seconds']}
 if 'performance_ns' in q['start']:
  dequeue=one([r for r in pr if r['request']==request],'supervisor.dequeue.first')
  runtime_qpc=[r for r in pr if r['phase']=='runtime.validate_installation'
   and q['start']['performance_ns']<=r['start']['performance_ns']
   and r['end']['performance_ns']<=send['start']['performance_ns']]
  inside=[r for r in runtime_qpc if adm['start']['performance_ns']<=r['start']['performance_ns']
   and r['end']['performance_ns']<=adm['end']['performance_ns']]
  row['qpc']={
   'admission_seconds':precise(adm),'gguf_seconds':precise(verify),
   'runtime_check_seconds':sum(precise(x) for x in runtime_qpc),
   'runtime_within_admission_seconds':sum(precise(x) for x in inside),
   'runtime_after_admission_seconds':sum(precise(x) for x in runtime_qpc if x not in inside),
   'admission_other_than_gguf_and_runtime_seconds':precise(adm)-precise(verify)-sum(precise(x) for x in inside),
   'native_prefill_decode_seconds':sum(precise(x) for x in decode),
   'request_lock_seconds':(owned['start']['performance_ns']-infer['start']['performance_ns'])/1e9,
   'send_to_worker_read_seconds':(read['start']['performance_ns']-send['start']['performance_ns'])/1e9,
   'emit_to_reader_queue_seconds':(queue['start']['performance_ns']-first['start']['performance_ns'])/1e9,
   'queue_to_supervisor_dequeue_seconds':(dequeue['start']['performance_ns']-queue['start']['performance_ns'])/1e9,
   'dequeue_precedes_existing_first_validation':True}
  assert all(v>=0 for v in row['qpc'].values() if type(v) is float)
 rows.append(row)
out={'purpose':'DIAGNOSTIC_ONLY','qualification':'NOT_EVALUATED',
 'original_slowdown_cause':'NOT_DEMONSTRATED',
 'environment':report['environment'],'sample_count':len(rows),'rows':rows,
 'limits':['same Family/Model is not the same original disposable host',
  'wall/CPU spans do not prove scheduler contention, CPU frequency, or disk bottleneck',
  'IPC/scheduling intervals include transport and wakeup; no ETW scheduler attribution',
  'observer wrappers/buffered flush and Windows monotonic clock resolution affect timings',
  'no original run phase telemetry can be reconstructed from this observation']}
(p/(root.name+'-phase-analysis.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([r for r in rows if r['case']=='en04'],indent=2))

