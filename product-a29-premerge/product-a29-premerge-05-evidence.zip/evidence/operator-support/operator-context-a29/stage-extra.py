"""Snapshot an explicit operator-approved list of evidence files; never includes directories."""
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path

ROOT=Path('/workspace/provelume')
CTX=ROOT/'.agent/native-lab/operator-context-a29'
ALLOWED=ROOT/'.agent/pr409-unblock'


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--files-json',type=Path,required=True)
 p.add_argument('--label',required=True)
 a=p.parse_args()
 if not re.fullmatch('[a-zA-Z0-9_-]+',a.label):raise SystemExit('invalid label')
 files=json.loads(a.files_json.read_text())
 if not isinstance(files,list) or not files or not all(isinstance(x,str) for x in files):raise SystemExit('explicit nonempty absolute file list required')
 output=CTX/'extensions'/a.label
 if output.exists():raise SystemExit('preserve old extension; use a new label')
 old=json.loads((CTX/'selection.json').read_text())['files']
 for manifest in (CTX/'extensions').glob('*/selection.json'):
  old+=json.loads(manifest.read_text())['files']
 seen={row['destination'] for row in old};prepared=[]
 for name in files:
  source=Path(name)
  if not source.is_absolute() or '..' in source.parts or source.is_symlink() or not source.is_file():raise SystemExit('regular absolute file required: '+name)
  actual=source.resolve()
  if not actual.is_relative_to(ALLOWED):raise SystemExit('extra selection outside operator evidence: '+name)
  destination=str(source)
  if destination in seen:raise SystemExit('duplicate selected destination: '+name)
  seen.add(destination)
  raw=source.read_bytes()
  try:text=raw.decode('utf-8')
  except UnicodeDecodeError:text=''
  if re.search(r'(?i)[?&](?:sig|x-amz-signature|x-amz-credential)=',text):raise SystemExit('private signed-URL envelope must remain outside operator context: '+name)
  prepared.append((source,destination,raw))
 output.mkdir(parents=True,exist_ok=False);rows=[]
 for index,(source,destination,raw) in enumerate(prepared):
  snapshot=output/('input-'+str(index).zfill(5));snapshot.write_bytes(raw)
  target=CTX/'accepted'/source.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.touch(exist_ok=False)
  rows.append({'source':str(source),'snapshot':str(snapshot),'destination':destination,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 manifest={'schema':'isolated-operator-selected-inputs/v1','authority':'NONE_SELECTED_INPUT_BYTES_ONLY','files':rows,'private_connector_envelopes':'NOT_SELECTED','preflight':'NOT_RUN'}
 path=output/'selection.json';path.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'manifest':str(path),'files':len(rows),'preflight':'NOT_RUN'}))


if __name__=='__main__':main()
