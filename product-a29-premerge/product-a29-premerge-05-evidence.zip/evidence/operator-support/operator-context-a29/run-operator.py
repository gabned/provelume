"""Run selected offline operator processing; never selects a preflight operation itself."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import uuid
from pathlib import Path

ROOT=Path('/workspace/provelume')
LAB=ROOT/'.agent/native-lab'
CTX=LAB/'operator-context-a29'
PYTHON=ROOT/'.agent/cpython312'
NODE=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node')
IMAGE='sha256:b928247c179560512f307f7e286fbdd449101ff77dbfc9260c4e9e39498e048d'
EXPECTED={'accepted':'cba9ff6c653bb53327ba397edf980099af90472a','candidate':'a29ce258278bb76bb9f92c11131360a22cf18d5b'}


def check_git(path, expected):
    def git(*args):
        return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
    if git('rev-parse','HEAD')!=expected or git('status','--porcelain','--untracked-files=all'):
        raise ValueError('Source head/cleanliness changed')
    if git('rev-parse','--is-shallow-repository')!='false' or git('for-each-ref','refs/replace/'):
        raise ValueError('Incomplete/replaced history')
    if not (path/'.git').is_dir() or (path/'.git/commondir').exists() or (path/'.git/info/grafts').exists():
        raise ValueError('External common-dir or grafts')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--label',required=True)
    p.add_argument('--extra-manifest',action='append',type=Path,default=[])
    p.add_argument('command',nargs=argparse.REMAINDER)
    a=p.parse_args()
    if not re.fullmatch('[a-zA-Z0-9_-]+',a.label): raise SystemExit('invalid label')
    command=a.command[1:] if a.command[:1]==['--'] else a.command
    if not command: raise SystemExit('explicit command required; no default operation')
    for name,head in EXPECTED.items(): check_git(CTX/name,head)
    manifests=[CTX/'selection.json',*a.extra_manifest]
    files=[];seen=set()
    for manifest in manifests:
        value=json.loads(manifest.read_text())
        if value['schema']!='isolated-operator-selected-inputs/v1': raise ValueError('unsupported selection')
        for row in value['files']:
            snapshot=Path(row['snapshot']);destination=row['destination']
            if destination in seen: raise ValueError('duplicate destination')
            seen.add(destination)
            if not destination.startswith('/workspace/provelume/.agent/'):
                raise ValueError('selection outside ignored evidence')
            if snapshot.is_symlink() or not snapshot.is_file(): raise ValueError('snapshot is not a regular file')
            raw=snapshot.read_bytes()
            if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
                raise ValueError('selected immutable bytes changed')
            target=CTX/'accepted'/Path(destination).relative_to(ROOT)
            if not target.is_file(): raise ValueError('mountpoint was not prepared')
            files.append((str(snapshot),destination,True))
    run=CTX/'runs'/(a.label+'-'+uuid.uuid4().hex)
    output=run/'out';temporary=run/'tmp'
    output.mkdir(parents=True,exist_ok=False);temporary.mkdir()
    mounts=[
        ('/usr','/usr',True),('/usr/lib','/lib',True),('/usr/lib64','/lib64',True),('/usr/bin','/bin',True),
        (str(CTX/'accepted'),'/workspace/provelume',True),
        (str(CTX/'accepted'),'/workspace/provelume-protocol',True),
        (str(CTX/'candidate'),'/workspace/provelume-product',True),
        (str(PYTHON),str(PYTHON),True),(str(ROOT/'.agent/native-sysroot'),str(ROOT/'.agent/native-sysroot'),True),
        (str(NODE),str(NODE),True),('/sys/devices/system/cpu','/sys/devices/system/cpu',True),
        (str(LAB/'etc/passwd'),'/etc/passwd',True),(str(LAB/'etc/group'),'/etc/group',True),
        (str(CTX/'helpers'),'/operator',True),(str(LAB/'scripts'),'/lab',True),
        ('/etc/ssl/certs','/etc/ssl/certs',True),(str(temporary),'/tmp',False),(str(output),'/out',False),
        *files,
    ]
    args=['docker','--host=unix:///var/run/docker.sock','run','--rm','--pull=never','--network=none','--cap-drop=ALL','--security-opt=no-new-privileges','--read-only','--user=1000:1000','--pids-limit=1024','--tmpfs=/home:rw,nosuid,nodev','--workdir=/workspace/provelume']
    for source,destination,readonly in mounts:
        args+=['--mount',f'type=bind,src={source},dst={destination}'+(',readonly' if readonly else '')]
    path=f'/workspace/provelume-protocol/.venv/bin:{PYTHON}/bin:{NODE}/bin:/usr/bin:/bin'
    args += [IMAGE,'/usr/bin/env','-i',f'PATH={path}','HOME=/home/lab','LANG=C.UTF-8','LC_ALL=C.UTF-8','TMPDIR=/tmp','PYTHONDONTWRITEBYTECODE=1','PIP_NO_INDEX=1','PIP_DISABLE_PIP_VERSION_CHECK=1',*command]
    record={'schema':'isolated-operator-execution/v1','label':a.label,'authority':'NONE_EXECUTION_CONTEXT_ONLY','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected_manifests':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in manifests],'head':EXPECTED,'command':command,'mounts':[{'source':s,'destination':d,'readonly':ro} for s,d,ro in mounts],'docker_argv':args,'output_parent':str(output),'preflight_selected_by_runner':False}
    (run/'execution-start.json').write_text(json.dumps(record,indent=2)+'\n')
    env=os.environ.copy()
    for key in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'): env.pop(key,None)
    result=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (run/'stdout').write_bytes(result.stdout);(run/'stderr').write_bytes(result.stderr)
    record.update(returncode=result.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout={'bytes':len(result.stdout),'sha256':hashlib.sha256(result.stdout).hexdigest()},stderr={'bytes':len(result.stderr),'sha256':hashlib.sha256(result.stderr).hexdigest()})
    (run/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'returncode':result.returncode,'run':str(run),'output_parent':str(output)}))
    raise SystemExit(result.returncode)


if __name__=='__main__': main()
