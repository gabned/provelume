"""Read original CPU ZIPs and replay accepted immutable evaluators offline."""
from __future__ import annotations
import argparse
import copy
import datetime
import errno
import hashlib
import importlib
import json
import os
import re
import socket
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

BASE = 'cba9ff6c653bb53327ba397edf980099af90472a'
HEAD = 'a29ce258278bb76bb9f92c11131360a22cf18d5b'
CONFIG = '6d26739dbb863788ae9de3ed3561b74995f03afde9bfe4cd8cef8c3dc25d0f99'
ARTIFACTS = [
    ('linux',12456568361,158511,'13e6f652078700fb10e77c7cc21498fa8899e91ce186987d3991229674763745'),
    ('windows',12456038886,22069,'04d18e06b6a4a50b72a17ec97758337301c9dbc5b659ed596c60065866c7fdb3'),
]


def sha(data): return hashlib.sha256(data).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--accepted-root',type=Path,required=True)
    parser.add_argument('--candidate-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=args.accepted_root.resolve(); candidate=args.candidate_root.resolve()
    out=args.output.resolve();out.mkdir(parents=False,exist_ok=False)
    receipt={'schema':'independent-accepted-cpu-replay/v1','authority':'NONE_EXECUTION_EVIDENCE_ONLY',
             'started_at':now(),'accepted_source':BASE,'candidate':HEAD,'result':'BLOCKED','platforms':[]}
    def put(name,value):
        path=out/name
        path.write_text(json.dumps(value,indent=2)+'\n')
        data=path.read_bytes()
        return {'path':name,'bytes':len(data),'sha256':sha(data)}
    def git(where,*argv):
        result=subprocess.run(['git','-C',str(where),*argv],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if result.returncode: raise ValueError('Git proof failed: '+' '.join(argv))
        return result.stdout
    try:
        assert git(root,'rev-parse','HEAD').decode().strip()==BASE
        assert git(candidate,'rev-parse','HEAD').decode().strip()==HEAD
        assert not git(root,'status','--porcelain','--untracked-files=no')
        assert not git(candidate,'status','--porcelain','--untracked-files=all')
        assert git(root,'rev-parse','--is-shallow-repository').strip()==b'false'
        assert git(candidate,'rev-parse','--is-shallow-repository').strip()==b'false'
        for where in (root,candidate):
            assert os.statvfs(where).f_flag & os.ST_RDONLY
        cpu=Path('/sys/devices/system/cpu')
        assert os.statvfs(cpu).f_flag & os.ST_RDONLY
        assert not Path('/var/run/docker.sock').exists() and not Path('/home/agent').exists()
        assert not [key for key in os.environ if any(part in key.upper() for part in ('TOKEN','SECRET','PROXY','CREDENTIAL'))]
        sock=socket.socket()
        try:
            sock.connect(('1.1.1.1',443))
        except OSError as exc:
            assert exc.errno in (errno.ENETUNREACH,errno.EHOSTUNREACH)
            network_errno=exc.errno
        else: raise AssertionError('Unexpected external network')
        finally: sock.close()
        mountinfo=Path('/proc/self/mountinfo').read_bytes()
        (out/'mountinfo.original.txt').write_bytes(mountinfo)
        receipt['environment']=put('environment.json',{'accepted_source_readonly':True,
            'candidate_readonly':True,'sys_cpu_readonly':True,'no_operator_credentials':True,
            'no_docker_socket':True,'external_network':'REFUSED','network_errno':network_errno,
            'mountinfo':{'path':'mountinfo.original.txt','bytes':len(mountinfo),'sha256':sha(mountinfo)}})
        # All accepted core/scripts are verified against exact Git blob+mode before import.
        inventory=[]
        entries=git(root,'ls-tree','-r','-z',BASE,'--','core','scripts','tests/fixtures/ai_runtime_quality.json')
        for entry in entries.split(b'\0'):
            if not entry: continue
            header,name=entry.split(b'\t',1);mode,kind,blob=header.decode().split();path=name.decode()
            assert kind=='blob' and mode in ('100644','100755')
            file=root/path;data=file.read_bytes()
            assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
            assert bool(file.stat().st_mode & 0o111)==(mode=='100755')
            inventory.append({'path':path,'mode':mode,'blob':blob,'bytes':len(data),'sha256':sha(data)})
        receipt['accepted_byte_inventory']=put('accepted-byte-inventory.json',{'source':BASE,'files':inventory})
        sys.path[:0]=[str(root/'core'),str(root)]
        evaluator=importlib.import_module('scripts.ai_runtime_report')
        observer=importlib.import_module('scripts.ai_runtime_network')
        contract=importlib.import_module('provelume.ai_runtime_contract')
        representations=importlib.import_module('provelume.representations')
        for module in (evaluator,observer,contract,representations):
            assert Path(module.__file__).is_relative_to(root)
        expected={**contract.CONFIGURATION,'windows_openmp_wait':'zero-blocktime-v1'}
        assert sha(representations.canonical_json_bytes(expected))==CONFIG
        corpus_raw=(root/'tests/fixtures/ai_runtime_quality.json').read_bytes()
        corpus=json.loads(corpus_raw)
        assert len(corpus)==20
        receipt['evaluator_sha256']=sha((root/'scripts/ai_runtime_report.py').read_bytes())
        receipt['observer_sha256']=sha((root/'scripts/ai_runtime_network.py').read_bytes())
        receipt['configuration_sha256']=CONFIG
        for system,identifier,size,digest in ARTIFACTS:
            archive_path=root/f'.agent/pr409-unblock/raw/artifact{identifier}.zip'
            archive_bytes=archive_path.read_bytes()
            assert len(archive_bytes)==size and sha(archive_bytes)==digest
            destination=out/system;destination.mkdir()
            member_rows=[];reports=[]
            with zipfile.ZipFile(archive_path) as archive:
                infos=archive.infolist();assert len({i.filename for i in infos})==len(infos)
                for info in infos:
                    hasher=hashlib.sha256();actual=0;chunks=[]
                    keep=info.filename=='s05-real.json' or info.filename=='s05-wfp.json' or re.fullmatch(r's05-network\.\d+',info.filename)
                    with archive.open(info) as member:
                        while True:
                            chunk=member.read(1024*1024)
                            if not chunk:break
                            hasher.update(chunk);actual+=len(chunk)
                            if keep: chunks.append(chunk)
                    assert actual==info.file_size
                    member_rows.append({'name':info.filename,'bytes':actual,'crc32':f'{info.CRC:08x}','sha256':hasher.hexdigest()})
                    if keep:
                        raw=b''.join(chunks)
                        if info.filename=='s05-real.json':
                            reports.append(raw);(destination/'s05-real.original.json').write_bytes(raw)
                        else:(destination/info.filename).write_bytes(raw)
            assert len(reports)==1
            original=json.loads(reports[0])
            assert original['source_commit']==HEAD and original['status']=='PASS'
            assert original.get('qualification')!='NOT_QUALIFIED'
            assert original['environment']['platform']==system
            assert original['configuration']==expected and original['configuration_sha256']==CONFIG
            assert original['runtime_lock_sha256']==contract.LOCK_SHA256
            assert original['model_sha256']==contract.MODEL_SHA256
            assert original['corpus_sha256']==sha(corpus_raw)
            assert all(original.get(key) is True for key in ('s06_required','s07_required','s08_required','iudicium_execution_required'))
            rows=original['samples'];assert len(rows)==60 and len(original['cold'])==3
            for run in range(3):
                for case,row in zip(corpus,rows[run*20:(run+1)*20],strict=True):
                    assert (row['run'],row['id'],row['language'],row['expected'])==(run,case['id'],case['language'],case['expected'])
                    actual=row['text'].strip().strip('.\"\' ').casefold()==case['expected'].casefold()
                    assert row['pass'] is actual
            quality={}
            for language in ('en','it'):
                subset=[row for row in rows if row['language']==language]
                score=sum(row['pass'] for row in subset)/len(subset)
                abstention=all(row['pass'] for row in subset if row['expected']=='UNKNOWN')
                quality[language]={'score':score,'n':len(subset),'abstention':abstention,
                    'status':'PASS' if len(subset)==30 and score>=.9 and abstention else 'FAIL'}
            assert original['quality']==quality
            assert [row['phase'] for row in original['s06']['samples']]==['cold','warm']*3
            assert [row['phase'] for row in original['s07']['samples']]==['cold','warm']
            assert len(original['s08']['samples'])==32 and len(original['s08']['performance'])==2
            assert len(original['iudicium_execution']['samples'])==2
            evaluated=copy.deepcopy(original)
            evaluator.evaluate(evaluated)
            observer.observe(evaluated,trace=destination/'s05-network' if system=='linux' else None,
                events=destination/'s05-wfp.json' if system=='windows' else None)
            assert evaluated['status']=='PASS' and evaluated['network']=='PASS'
            assert len(evaluated['gates'])==28 and all(v=='PASS' for v in evaluated['gates'].values())
            assert evaluated['gates']==original['gates']
            report_ref=put(f'{system}/s05-real.independent-evaluation.json',evaluated)
            members_ref=put(f'{system}/complete-member-inventory.json',member_rows)
            result={'platform':system,'artifact_id':identifier,'zip_bytes':size,'zip_sha256':digest,
                'members_crc_read':len(member_rows),'uncompressed_bytes_read':sum(r['bytes'] for r in member_rows),
                'original_report_sha256':sha(reports[0]),'source_head':HEAD,'configuration_sha256':CONFIG,
                'coverage':{'corpus_samples':len(rows),'cold':len(original['cold']),
                    'governed':len(original['s06']['samples']),'s07':len(original['s07']['samples']),
                    's08':len(original['s08']['samples']),'iudicium':len(original['iudicium_execution']['samples'])},
                'gates':evaluated['gates'],'network_observation':evaluated['network_observation'],
                'independent_evaluation':report_ref,'complete_member_inventory':members_ref}
            receipt['platforms'].append(result)
        assert not git(root,'status','--porcelain','--untracked-files=no')
        assert not git(candidate,'status','--porcelain','--untracked-files=all')
        receipt['result']='PASS'
    except Exception as exc:
        receipt['reason']=str(exc);receipt['exception']=type(exc).__name__
        raise
    finally:
        receipt['completed_at']=now();put('receipt.json',receipt)
        print(json.dumps({'result':receipt['result'],'head':HEAD,'output':str(out),
            'platforms':len(receipt['platforms']),'reason':receipt.get('reason')}),flush=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
