"""Inspect/verify preserved Windows groups with accepted code and external Git proof.

No fetch, rerun, status synthesis or standalone candidate qualification occurs.
"""
from __future__ import annotations
import argparse,datetime,hashlib,importlib.util,json,os,re,subprocess,sys,zipfile
from pathlib import Path

BASE='cba9ff6c653bb53327ba397edf980099af90472a'
HEAD='a29ce258278bb76bb9f92c11131360a22cf18d5b'
TREE='dd730e93c32ca9d82c17caaad0056ccf7ceea06c'
RUNS={'39848292362':{0:12456712099,1:12457051352},'39850661559':{0:12457298434,1:12457856523}}


def now():return datetime.datetime.now(datetime.timezone.utc)
def sha(data):return hashlib.sha256(data).hexdigest()
def require(ok,text):
 if not ok:raise ValueError(text)
def unique(pairs):
 value={}
 for key,item in pairs:
  require(key not in value,'Duplicate JSON key');value[key]=item
 return value
def read_json(data):
 def constant(value):raise ValueError('Nonfinite JSON constant: '+value)
 return json.loads(data,object_pairs_hook=unique,parse_constant=constant)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True)


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('mode',choices=['inspect','verify'])
 p.add_argument('--accepted-root',type=Path,required=True)
 p.add_argument('--candidate-root',type=Path,required=True)
 p.add_argument('--manifest',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 report={'schema':'provelume-windows-originals-offline/v1','mode':a.mode,'result':'REFUSED','qualification':'NOT_QUALIFIED_STANDALONE_EVIDENCE_ONLY','started_at':now().isoformat(),'accepted_head':BASE,'candidate_head':HEAD,'candidate_tree':TREE,'commands':[],'runs':[]}
 def put(name,data):
  path=out/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
  return {'path':str(path.relative_to(out)),'bytes':len(data),'sha256':sha(data)}
 def git(root,*args):
  index=len(report['commands'])+1;start=now();argv=['git','-C',str(root),*args]
  result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  row={'argv':argv,'started_at':start.isoformat(),'completed_at':now().isoformat(),'returncode':result.returncode,'stdout':put(f'commands/{index:05d}.stdout',result.stdout),'stderr':put(f'commands/{index:05d}.stderr',result.stderr)}
  report['commands'].append(row);require(result.returncode==0,'Git source proof unavailable');return result.stdout
 def reference(item):
  path=Path(item['path']);path=path if path.is_absolute() else a.manifest.resolve().parent/path
  require(path.is_file() and not path.is_symlink(),'Regular retained evidence file required')
  data=path.read_bytes();require(type(item['bytes']) is int and len(data)==item['bytes'] and re.fullmatch('[0-9a-f]{64}',item['sha256']) and sha(data)==item['sha256'],'Retained evidence byte mismatch')
  return data
 def git_proof(row,preview):
  proof=row.get('preview_proof');require(isinstance(proof,dict),'External original Git commit proof required')
  raw=reference(proof['response']);meta=read_json(reference(proof['acquisition']))
  endpoint='https://api.github.com/repos/gabned/provelume/git/commits/'+preview
  require(meta['endpoint']==endpoint or meta['endpoint'].startswith(endpoint+'?'),'Preview acquisition endpoint mismatch')
  stamps=[datetime.datetime.fromisoformat(meta[key].replace('Z','+00:00')) for key in ('started_at','completed_at')]
  require(all(t.tzinfo is not None for t in stamps) and stamps[0]<=stamps[1]<=now(),'Preview acquisition timestamps invalid or future')
  code=meta.get('exit_code',meta.get('returncode'))
  require(type(code) is int and code==0 and meta.get('timed_out') is not True and meta.get('isError') is not True and meta.get('error_code') is None and meta.get('signal') is None,'Preview acquisition failed')
  returned=meta.get('response_sha256',meta.get('stdout',{}).get('sha256',meta.get('stdout_sha256')))
  require(returned==sha(raw),'Acquisition hash does not bind original Git response')
  size=meta.get('stdout',{}).get('bytes',meta.get('stdout_bytes'))
  if size is not None:require(size==len(raw),'Acquisition original size mismatch')
  body=raw
  if raw.startswith(b'HTTP/'):
   normalized=raw.replace(b'\r\n',b'\n');headers,body=normalized.split(b'\n\n',1)
   require(re.fullmatch(rb'HTTP/[^ ]+ 200(?: .*)?',headers.splitlines()[0]) is not None,'Git response HTTP status is not 200')
  value=read_json(body)
  require(value.get('sha')==preview,'Actual Git object SHA differs from Windows preview')
  require([v.get('sha') for v in value.get('parents',[])]==[BASE,HEAD],'Actual preview ordered parents differ')
  require(value.get('tree',{}).get('sha')==TREE,'Actual preview tree differs from exact candidate')
  return {'result':'PASS','preview_commit':preview,'parents':[BASE,HEAD],'tree':TREE,'response':put('git-proofs/'+row['run_id']+'.response.original',raw),'acquisition':put('git-proofs/'+row['run_id']+'.acquisition.original.json',reference(proof['acquisition'])),'endpoint':meta['endpoint']}
 try:
  accepted=a.accepted_root.resolve();candidate=a.candidate_root.resolve()
  require(all(os.statvfs(x).f_flag&os.ST_RDONLY for x in (accepted,candidate,Path('/sys/devices/system/cpu'))),'Sources and CPU topology must be read-only')
  require(not Path('/var/run/docker.sock').exists() and not Path('/home/agent').exists(),'Operator socket/home exposed')
  require(not [x for x in os.environ if any(y in x.upper() for y in ('TOKEN','SECRET','PROXY','CREDENTIAL','SIGNER'))],'Credential-bearing environment exposed')
  for root,expected in ((accepted,BASE),(candidate,HEAD)):
   require(git(root,'rev-parse','HEAD').decode().strip()==expected,'Source head mismatch')
   require(not git(root,'status','--porcelain','--untracked-files=all').strip(),'Source dirty')
   require(git(root,'rev-parse','--is-shallow-repository').strip()==b'false' and not git(root,'for-each-ref','refs/replace/').strip(),'Incomplete/replaced source history')
   require((root/'.git').is_dir() and not (root/'.git/commondir').exists() and not (root/'.git/info/grafts').exists(),'External common-dir or grafts')
  require(git(candidate,'rev-parse','HEAD^{tree}').decode().strip()==TREE,'Exact candidate tree mismatch')
  inventory=[]
  for record in git(accepted,'ls-tree','-r','-z',BASE,'--','tools').split(b'\0'):
   if not record:continue
   metadata,name=record.split(b'\t',1);mode,kind,blob=metadata.decode().split();name=name.decode()
   if not name.endswith('.py'):continue
   require(kind=='blob' and mode in ('100644','100755'),'Unsupported accepted tools object')
   path=accepted/name;raw=git(accepted,'show',BASE+':'+name)
   require(path.is_file() and not path.is_symlink() and path.read_bytes()==raw,'Accepted tool bytes changed: '+name)
   require(bool(path.stat().st_mode&0o111)==(mode=='100755'),'Accepted tool mode changed: '+name)
   require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob,'Accepted tool Git blob mismatch')
   inventory.append({'path':name,'mode':mode,'blob':blob,'bytes':len(raw),'sha256':sha(raw)})
  needed={'tools/agent_protocol_work_check.py','tools/agent_protocol_work_source.py'}
  require(needed<={r['path'] for r in inventory},'Accepted local dependency inventory incomplete')
  report['accepted_tools_inventory']=put('accepted-tools-inventory.json',(json.dumps(inventory,indent=2)+'\n').encode())
  def module(name,path):
   spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value);require(Path(value.__file__).resolve()==path.resolve(),'Imported module origin changed');return value
  source=module('agent_protocol_work_source',accepted/'tools/agent_protocol_work_source.py')
  checker=module('accepted_windows_work_check',accepted/'tools/agent_protocol_work_check.py')
  require(checker.source is source,'Accepted work source dependency was replaced')
  raw_manifest=a.manifest.read_bytes();manifest=read_json(raw_manifest);report['manifest']=put('manifest.original.json',raw_manifest)
  require(manifest['schema']=='windows-original-pairs/v1','Unsupported originals manifest')
  rows=manifest['runs'];require(len(rows)==2 and {r['run_id'] for r in rows}==set(RUNS),'Complete initial/ready run cohort required')
  for row in rows:
   require(row.get('run_attempt')=='1' and row.get('event')=='pull_request','Exact ordinary attempt/event required')
   artifacts=row['artifacts'];require(len(artifacts)==2 and {v['group'] for v in artifacts}=={0,1},'Both unique groups required')
   groups=[];archives=[]
   for item in sorted(artifacts,key=lambda v:v['group']):
    group=item['group'];require(type(group) is int and item['artifact_id']==RUNS[row['run_id']][group],'Original run/group/artifact binding differs')
    path=Path(item['path']);path=path if path.is_absolute() else a.manifest.resolve().parent/path
    raw=reference(item);records={};members=[]
    with zipfile.ZipFile(path) as archive:
     names=[v.filename for v in archive.infolist()];require(len(names)==len(set(names)),'Duplicate ZIP member')
     for info in archive.infolist():
      require(not info.filename.startswith('/') and all(v not in ('','..','.') for v in info.filename.split('/')),'Noncanonical ZIP member path')
      digest=hashlib.sha256();size=0;chunks=[]
      with archive.open(info) as member:
       while True:
        chunk=member.read(1024*1024)
        if not chunk:break
        digest.update(chunk);size+=len(chunk)
        if info.filename.endswith('.json'):chunks.append(chunk)
      require(size==info.file_size,'ZIP original member size differs')
      members.append({'path':info.filename,'bytes':size,'sha256':digest.hexdigest(),'crc32':f'{info.CRC:08x}'})
      if info.filename.endswith('.json'):records[info.filename]=read_json(b''.join(chunks))
    expected_json={f'group-{group}.json',f'inventory-{group}.json',*(f'shard-{s}/shard-{s}.json' for s in (group*2,group*2+1))}
    require(set(records)==expected_json,'Unique group and exact companion JSON records required')
    value=records[f'group-{group}.json'];require(value.get('group')==group,'Group report differs from original lane')
    require(canonical(records[f'inventory-{group}.json'])==canonical(value.get('inventory')),'Companion independent inventory differs from embedded record')
    embedded=value.get('shards',[]);require(len(embedded)==2 and {s.get('shard') for s in embedded}=={group*2,group*2+1},'Embedded shard pair differs')
    for shard in embedded:require(canonical(records[f"shard-{shard['shard']}/shard-{shard['shard']}.json"])==canonical(shard),'Companion shard differs from embedded record')
    groups.append(value);archives.append({'artifact_id':item['artifact_id'],'group':group,'path':str(path),'bytes':len(raw),'sha256':sha(raw),'member_count':len(members),'members':members})
   preview=groups[0].get('identity',{}).get('commit');require(type(preview) is str and re.fullmatch('[0-9a-f]{40}',preview),'Reported preview commit missing')
   expected={'commit':preview,'tree':TREE,'run_id':row['run_id'],'run_attempt':'1','event':'pull_request'}
   checked=checker.verify_windows_reports(groups,expected)
   proof=git_proof(row,preview) if a.mode=='verify' else {'result':'NOT_RUN','reason':'EXTERNAL_ORIGINAL_GIT_COMMIT_PROOF_REQUIRED'}
   report['runs'].append({'run_id':row['run_id'],'run_attempt':'1','event':'pull_request','reported_preview_commit':preview,'accepted_verifier':checked,'preview_git_proof':proof,'artifacts':archives})
  report['result']='VERIFIED_NOT_QUALIFIED' if a.mode=='verify' else 'INSPECTED_NOT_QUALIFIED'
  report['external_preview_proof_complete']=a.mode=='verify'
 except Exception as exc:report.update(result='REFUSED',reason=str(exc),exception=type(exc).__name__)
 report['completed_at']=now().isoformat();put('receipt.json',(json.dumps(report,indent=2)+'\n').encode())
 print(json.dumps({'result':report['result'],'mode':a.mode,'qualification':report['qualification'],'output':str(out),'runs':[{'run_id':r['run_id'],'preview_commit':r['reported_preview_commit'],'windows_result':r['accepted_verifier']['result']} for r in report['runs']],'reason':report.get('reason')}))
 return 1 if report['result']=='REFUSED' else 0


if __name__=='__main__':raise SystemExit(main())
