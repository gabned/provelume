"""Run a reviewed stdlib-only script with explicit readonly ignored evidence inputs."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import uuid
from pathlib import Path

ROOT = Path('/workspace/provelume')
LAB = ROOT / '.agent/native-lab'
PYTHON = ROOT / '.agent/cpython312'
IMAGE = 'sha256:b928247c179560512f307f7e286fbdd449101ff77dbfc9260c4e9e39498e048d'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def inventory(path):
    if path.is_symlink() or not path.exists():
        raise ValueError('missing/symlink input: ' + str(path))
    paths = [path] if path.is_file() else sorted(path.rglob('*'))
    rows = []
    for selected in paths:
        if selected.is_symlink():
            raise ValueError('symlink inside selected input: ' + str(selected))
        if selected.is_dir():
            continue
        if not selected.is_file():
            raise ValueError('nonregular selected input: ' + str(selected))
        raw = selected.read_bytes()
        rows.append({'path': str(selected), 'bytes': len(raw),
                     'sha256': hashlib.sha256(raw).hexdigest()})
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label', required=True)
    parser.add_argument('--script', type=Path, required=True)
    parser.add_argument('--input', type=Path, action='append', default=[])
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not re.fullmatch('[a-zA-Z0-9_-]+', args.label):
        raise SystemExit('safe unique label required')
    selected = [args.script, *args.input]
    for path in selected:
        if not path.is_absolute() or path.resolve() != path or not path.is_relative_to(ROOT / '.agent'):
            raise ValueError('input must be original absolute ignored evidence path')
        if any(path != other and path.is_relative_to(other) for other in selected):
            raise ValueError('overlapping selected input mounts')
    if len(set(selected)) != len(selected) or not args.script.is_file():
        raise ValueError('duplicate input or script not a file')
    before = [row for path in selected for row in inventory(path)]
    run = LAB / 'static-audits' / (args.label + '-' + uuid.uuid4().hex)
    output = run / 'out'
    temporary = run / 'tmp'
    output.mkdir(parents=True, exist_ok=False)
    temporary.mkdir()
    (run / 'selected-inputs.json').write_text(json.dumps(before, indent=2) + '\n')
    inputs_map = run / 'inputs.json'
    inputs_map.write_text(json.dumps([str(path) for path in selected]) + '\n')
    mounts = [('/usr', '/usr', True), ('/usr/lib', '/lib', True),
              ('/usr/lib64', '/lib64', True), ('/usr/bin', '/bin', True),
              (str(PYTHON), str(PYTHON), True),
              (str(ROOT / '.agent/native-sysroot'), str(ROOT / '.agent/native-sysroot'), True),
              (str(LAB / 'etc/passwd'), '/etc/passwd', True),
              (str(LAB / 'etc/group'), '/etc/group', True),
              ('/sys/devices/system/cpu', '/sys/devices/system/cpu', True),
              (str(LAB / 'scripts/static-audit-inside.py'), '/lab/static-audit-inside.py', True),
              (str(inputs_map), '/lab/inputs.json', True),
              (str(temporary), '/tmp', False), (str(output), '/out', False),
              *[(str(path), str(path), True) for path in selected]]
    command = [str(PYTHON / 'bin/python3.12'), '/lab/static-audit-inside.py',
               str(args.script), *(args.arguments[1:] if args.arguments[:1] == ['--'] else args.arguments)]
    docker = ['docker', '--host=unix:///var/run/docker.sock', 'run', '--rm', '--pull=never',
              '--network=none', '--cap-drop=ALL', '--security-opt=no-new-privileges',
              '--read-only', '--user=1000:1000', '--pids-limit=1024',
              '--tmpfs=/home:rw,nosuid,nodev', '--workdir=/tmp']
    for source, destination, readonly in mounts:
        docker += ['--mount', f'type=bind,src={source},dst={destination}' + (',readonly' if readonly else '')]
    docker += [IMAGE, '/usr/bin/env', '-i',
               f'PATH={PYTHON}/bin:/usr/bin:/bin', 'HOME=/home/lab', 'LANG=C.UTF-8',
               'LC_ALL=C.UTF-8', 'TMPDIR=/tmp', 'PYTHONDONTWRITEBYTECODE=1', *command]
    record = {'schema': 'isolated-static-audit-launch/v1', 'label': args.label,
              'authority': 'NONE_EXECUTION_CONTEXT_ONLY', 'started_at': now(),
              'selected_inputs': before, 'command': command, 'docker_argv': docker,
              'mounts': [{'source': s, 'destination': d, 'readonly': ro} for s, d, ro in mounts]}
    (run / 'launch-start.json').write_text(json.dumps(record, indent=2) + '\n')
    environment = os.environ.copy()
    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'):
        environment.pop(key, None)
    result = subprocess.run(docker, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (run / 'stdout').write_bytes(result.stdout)
    (run / 'stderr').write_bytes(result.stderr)
    after = [row for path in selected for row in inventory(path)]
    record.update({'completed_at': now(), 'returncode': result.returncode,
                   'selected_inputs_unchanged': before == after,
                   'stdout': {'bytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest()},
                   'stderr': {'bytes': len(result.stderr), 'sha256': hashlib.sha256(result.stderr).hexdigest()}})
    (run / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'run': str(run), 'returncode': result.returncode,
                      'selected_inputs_unchanged': before == after}))
    return result.returncode if before == after else 2


if __name__ == '__main__':
    raise SystemExit(main())
