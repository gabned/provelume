"""Run one reviewed stdlib-only audit after proving this disposable context."""
from __future__ import annotations
import datetime
import errno
import hashlib
import json
import os
import socket
import subprocess
import sys
from pathlib import Path


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    inputs = json.loads(Path('/lab/inputs.json').read_text())
    output = Path('/out')
    mountinfo = Path('/proc/self/mountinfo').read_bytes()
    (output / 'mountinfo.txt').write_bytes(mountinfo)
    rows = {row.split()[4]: row.split()[5].split(',')
            for row in mountinfo.decode().splitlines()}
    for selected in [*inputs, '/sys/devices/system/cpu']:
        assert os.statvfs(selected).f_flag & os.ST_RDONLY, selected
        assert 'ro' in rows[selected], selected
    assert os.statvfs('/').f_flag & os.ST_RDONLY
    allowed = {'PATH', 'HOME', 'LANG', 'LC_ALL', 'TMPDIR', 'PYTHONDONTWRITEBYTECODE'}
    assert set(os.environ) <= allowed, sorted(set(os.environ) - allowed)
    assert not any(Path(p).exists() for p in (
        '/home/agent', '/root/.aws', '/root/.config', '/workspace/.aws',
        '/workspace/.git', '/workspace/provelume/.git',
        '/workspace/provelume-product/.git', '/run/docker.sock', '/var/run/docker.sock'))
    assert not list(Path('/home').iterdir())
    connection = socket.socket()
    try:
        connection.connect(('1.1.1.1', 443))
    except OSError as error:
        assert error.errno in (errno.ENETUNREACH, errno.EHOSTUNREACH)
        network = {'external_connect': 'REFUSED', 'errno': error.errno}
    else:
        raise AssertionError('unexpected external connection')
    finally:
        connection.close()
    probe = {
        'schema': 'isolated-static-audit-probe/v1', 'result': 'PASS',
        'observed_at': now(), 'readonly_inputs': inputs,
        'sys_cpu_readonly': True, 'readonly_root': True,
        'no_source_checkout': True, 'no_operator_home': True,
        'no_credential_environment': True, 'no_docker_socket': True,
        'network': network, 'environment_keys': sorted(os.environ),
        'mountinfo': {'path': 'mountinfo.txt', 'bytes': len(mountinfo),
                      'sha256': hashlib.sha256(mountinfo).hexdigest()},
    }
    (output / 'probe.json').write_text(json.dumps(probe, indent=2) + '\n')
    command = [sys.executable, '-I', *sys.argv[1:]]
    started = now()
    process = subprocess.run(command, cwd='/tmp', stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
    (output / 'audit.stdout').write_bytes(process.stdout)
    (output / 'audit.stderr').write_bytes(process.stderr)
    receipt = {
        'schema': 'disposable-static-audit-execution/v1',
        'authority': 'NONE_EXECUTION_EVIDENCE_ONLY',
        'started_at': started, 'completed_at': now(),
        'command': command, 'cwd': '/tmp', 'returncode': process.returncode,
        'probe': {'path': 'probe.json', 'sha256': hashlib.sha256(
            (output / 'probe.json').read_bytes()).hexdigest()},
        'stdout': {'path': 'audit.stdout', 'bytes': len(process.stdout),
                   'sha256': hashlib.sha256(process.stdout).hexdigest()},
        'stderr': {'path': 'audit.stderr', 'bytes': len(process.stderr),
                   'sha256': hashlib.sha256(process.stderr).hexdigest()},
    }
    (output / 'execution-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return process.returncode


if __name__ == '__main__':
    raise SystemExit(main())
