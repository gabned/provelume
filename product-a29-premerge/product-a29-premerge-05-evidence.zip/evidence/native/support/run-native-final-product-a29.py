"""Capture original native command outcomes in one already-isolated context.

This is disposable execution evidence, not lifecycle or qualification authority.
"""
from __future__ import annotations
import datetime
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    expected = sys.argv[1]
    if not re.fullmatch('[0-9a-f]{40}', expected):
        raise SystemExit('exact full head required')
    root = Path.cwd()
    output = root / '.agent/native-final'
    output.mkdir(parents=True, exist_ok=False)
    receipt = {
        'schema': 'disposable-native-execution-evidence/v1',
        'started_at': now(),
        'expected_head': expected,
        'candidate_root': str(root),
        'authority': 'NONE_EXECUTION_EVIDENCE_ONLY',
        'commands': [],
    }

    def run(label, argv):
        start = now()
        result = subprocess.run(argv, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout = output / (label + '.stdout')
        stderr = output / (label + '.stderr')
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        row = {
            'label': label, 'argv': argv, 'cwd': str(root),
            'started_at': start, 'completed_at': now(), 'returncode': result.returncode,
            'stdout': {'path': str(stdout.relative_to(root)), 'bytes': len(result.stdout),
                       'sha256': sha(result.stdout)},
            'stderr': {'path': str(stderr.relative_to(root)), 'bytes': len(result.stderr),
                       'sha256': sha(result.stderr)},
        }
        receipt['commands'].append(row)
        print(json.dumps(row), flush=True)
        return result

    def save(result):
        receipt['result'] = result
        receipt['completed_at'] = now()
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

    head = run('head-before', ['git', 'rev-parse', 'HEAD'])
    tree = run('tree-before', ['git', 'rev-parse', 'HEAD^{tree}'])
    clean = run('status-before', ['git', 'status', '--porcelain'])
    if (head.returncode or tree.returncode or clean.returncode
            or head.stdout.decode().strip() != expected or clean.stdout):
        save('REFUSED_SOURCE_IDENTITY_OR_DIRTY_TREE')
        return 2
    receipt['head'] = expected
    receipt['tree'] = tree.stdout.decode().strip()
    mountinfo = Path('/proc/self/mountinfo').read_bytes()
    (output / 'mountinfo.txt').write_bytes(mountinfo)
    receipt['mountinfo'] = {'path': '.agent/native-final/mountinfo.txt',
                            'bytes': len(mountinfo), 'sha256': sha(mountinfo)}
    commands = [
        ('environment-probe', [sys.executable, '/lab/probe.py']),
        ('pip-check', [sys.executable, '-m', 'pip', 'check']),
        ('canonical-before', [sys.executable, 'tools/agent_protocol_v2.py', 'verify']),
        ('ruff', [sys.executable, '-m', 'ruff', 'check', '--cache-dir',
                  '.agent/ruff-cache', 'core', 'tests', 'scripts', 'tools']),
        ('fullsuite', [sys.executable, '-m', 'pytest', '-q']),
        ('diff-check', ['git', 'diff', '--check']),
        ('canonical-after', [sys.executable, 'tools/agent_protocol_v2.py', 'verify']),
    ]
    failed = False
    for label, argv in commands:
        if run(label, argv).returncode:
            failed = True
            break
    after = run('head-after', ['git', 'rev-parse', 'HEAD'])
    after_tree = run('tree-after', ['git', 'rev-parse', 'HEAD^{tree}'])
    after_clean = run('status-after', ['git', 'status', '--porcelain'])
    receipt['source_unchanged_after'] = (
        not any(x.returncode for x in (after, after_tree, after_clean))
        and after.stdout == head.stdout and after_tree.stdout == tree.stdout
        and not after_clean.stdout
    )
    save('PASS' if not failed and receipt['source_unchanged_after'] else 'FAIL')
    return 0 if receipt['result'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
