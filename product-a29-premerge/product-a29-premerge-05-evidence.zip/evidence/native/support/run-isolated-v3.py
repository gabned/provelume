from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path
ROOT=Path('/workspace/provelume')
LAB=ROOT/'.agent/native-lab'
PYTHON=ROOT/'.agent/cpython312'
NODE=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node')
source=Path(sys.argv[1]).resolve()
command=sys.argv[2:]
if not command: raise SystemExit('source and command required')
env=os.environ.copy()
for key in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):
    env.pop(key,None)
args=['docker','--host=unix:///var/run/docker.sock','run','--rm','--network=none','--cap-drop=ALL','--security-opt=no-new-privileges','--read-only','--user=1000:1000','--pids-limit=1024','--tmpfs=/home:rw,nosuid,nodev','--workdir=/workspace/provelume-protocol']
temporary=LAB/'host-tmp'/('run-'+str(os.getpid()))
temporary.mkdir(parents=True,exist_ok=False)
for src,dst,readonly in [(str(temporary),'/tmp',False),(str(LAB/'etc/passwd'),'/etc/passwd',True),(str(LAB/'etc/group'),'/etc/group',True),('/usr','/usr',True),('/usr/lib','/lib',True),('/usr/lib64','/lib64',True),('/usr/bin','/bin',True),('/sys/devices/system/cpu','/sys/devices/system/cpu',True),(str(PYTHON),str(PYTHON),True),(str(ROOT/'.agent/native-sysroot'),str(ROOT/'.agent/native-sysroot'),True),(str(NODE),str(NODE),True),(str(LAB/'wheels'),'/wheels',True),(str(LAB/'scripts'),'/lab',True),(str(source),'/workspace/provelume-protocol',False),(str(source/'tools/agent_protocol_core'),'/workspace/provelume-protocol/tools/agent_protocol_core',True),('/etc/ssl/certs','/etc/ssl/certs',True)]:
    args+=['--mount',f'type=bind,src={src},dst={dst}'+(',readonly' if readonly else '')]
path=f'/workspace/provelume-protocol/.venv/bin:{PYTHON}/bin:{NODE}/bin:/usr/bin:/bin'
args+=['provelume-native-lab:empty','/usr/bin/env','-i',f'PATH={path}','HOME=/home/lab','LANG=C.UTF-8','LC_ALL=C.UTF-8','TMPDIR=/tmp','PYTHONDONTWRITEBYTECODE=1','PIP_NO_INDEX=1','PIP_FIND_LINKS=/wheels','PIP_DISABLE_PIP_VERSION_CHECK=1','PIP_CACHE_DIR=/tmp/pip-cache',*command]
raise SystemExit(subprocess.call(args,env=env))
