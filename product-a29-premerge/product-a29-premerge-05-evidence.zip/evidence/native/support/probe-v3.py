import errno, fcntl, importlib.metadata, json, os, pathlib, socket, ssl, struct, subprocess, sys, tempfile
cpu=pathlib.Path('/sys/devices/system/cpu')
mounts=pathlib.Path('/proc/self/mountinfo').read_text().splitlines()
rows=[x for x in mounts if x.split()[4]==str(cpu)]
assert rows and 'ro' in rows[0].split()[5].split(',')
assert os.statvfs(cpu).f_flag & os.ST_RDONLY
vendor=pathlib.Path('/workspace/provelume-protocol/tools/agent_protocol_core')
assert os.statvfs(vendor).f_flag & os.ST_RDONLY
assert (cpu/'online').read_text().strip()
assert not pathlib.Path('/var/run/docker.sock').exists()
assert not pathlib.Path('/home/agent').exists()
assert not pathlib.Path('/workspace/provelume/.git').exists()
assert not [x for x in os.environ if any(y in x.upper() for y in ('TOKEN','SECRET','PROXY','CREDENTIAL'))]
s=socket.socket()
try:
    s.connect(('1.1.1.1',443))
except OSError as exc:
    assert exc.errno in (errno.ENETUNREACH,errno.EHOSTUNREACH)
    network={'external_connect': 'REFUSED', 'errno':exc.errno}
else: raise AssertionError('unexpected network')
finally:s.close()
fd=os.memfd_create('lab-probe',os.MFD_ALLOW_SEALING)
fcntl.fcntl(fd,fcntl.F_ADD_SEALS,fcntl.F_SEAL_WRITE|fcntl.F_SEAL_GROW|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_SEAL)
os.close(fd)
from provelume.ai_runtime_cpu import linux_pair
pair, topology = linux_pair(set(os.sched_getaffinity(0)))
assert len(pair) == 2 and topology['selected_physical_cores'] == 2
with tempfile.TemporaryDirectory() as temp:
    path=pathlib.Path(temp)/'acl-probe'
    path.write_bytes(b'synthetic')
    acl=struct.pack('<I',2)+b''.join(struct.pack('<HHI',tag,mode,identity) for tag,mode,identity in [(1,6,0xFFFFFFFF),(4,0,0xFFFFFFFF),(8,4,os.getgid()),(16,4,0xFFFFFFFF),(32,0,0xFFFFFFFF)])
    os.setxattr(path,'system.posix_acl_access',acl)
    os.setxattr(path,'user.provelume-lab',b'synthetic')
    assert os.getxattr(path,'system.posix_acl_access')==acl
    assert os.getxattr(path,'user.provelume-lab')==b'synthetic'
versions={name:importlib.metadata.version(name) for name in ['provelume','pip','pytest','pypdf','ruff']}
print(json.dumps({'python':sys.version,'ssl':ssl.OPENSSL_VERSION,'node':subprocess.check_output(['node','--version'],text=True).strip(),'versions':versions,'cpu_mount':rows[0],'cpu_online':(cpu/'online').read_text().strip(),'sys_cpu_readonly':True,'canonical_vendor_readonly':True,'topology':topology,'posix_acl_xattr':True,'memfd_seal':True,'network':network,'no_operator_credentials':True,'no_docker_socket':True},indent=2))
