"""Independent arithmetic audit of the immutable predeclared diagnostic cohort."""
import hashlib
import json
import statistics
from pathlib import Path

root = Path(__file__).parent
report = root / 'raw/artifact12454944310/s06-governed-diagnostic.json'
r = json.loads(report.read_bytes())
assert hashlib.sha256(report.read_bytes()).hexdigest() == '79b5bba695510586fa49d41127537dc2508a5efbe2d618a76227c3f3cd0319ce'
assert r['source_commit'] == '5af1bf5039a41a1b8bfcbee32c31d30b2bcd88f4'
assert r['qualification'] == 'NOT_QUALIFIED' and r['status'] == 'DIAGNOSTIC'
assert len(r['samples']) == 60 and len(r['cold']) == 3 and not r['failures']
e, samples = r['governed_experiment'], r['s06']['samples']
blocks = [('A1', 'default'), ('B1', 'blocktime0'), ('B2', 'blocktime0'), ('A2', 'default')]
expected = [(b, m, i, p) for b, m in blocks for i in range(3) for p in ('cold', 'warm')]
assert len(samples) == 24
assert [(s['block'], s['mode'], s['pair'], s['phase']) for s in samples] == expected
assert len(e['planned_cells']) == 24 and all(c['outcome'] == 'MEASURED' for c in e['planned_cells'])
assert len(e['fixed_payloads']) == 6 and len(r['s06']['diagnostic_self_tests']) == 15
fixed = {(p['pair'], p['phase']): p for p in e['fixed_payloads']}
topology = samples[0]['worker']['load']['limits']['cpu_topology']
idle = {b: [] for b, _ in blocks}
for s in samples:
    key, w = (s['pair'], s['phase']), s['worker']
    raw = s['synthetic_diagnostic_input']['utf8'].encode()
    assert hashlib.sha256(raw).hexdigest() == fixed[key]['sha256'] == s['synthetic_diagnostic_input']['sha256']
    assert raw == fixed[key]['utf8'].encode() and s['status'] == 'succeeded'
    n, lim = w['diagnostic_native'], w['load']['limits']
    assert lim['cpu_topology'] == topology and topology['selected_physical_cores'] == 2
    assert lim['memory_bytes'] == 3 * 1024**3 and lim['priority'] == 'JobObject:below-normal'
    assert w['memory']['private_bytes'] <= lim['memory_bytes']
    setting = n['blocktime']
    assert setting['original_ms'] == setting['restored_ms'] == 200 and setting['restored']
    assert setting['observed_ms'] == (0 if s['mode'] == 'blocktime0' else 200)
    counters = n['idle_process_counters']['groups']['process_times']
    assert counters['status'] == 'OBSERVED'
    idle[s['block']].append((counters['kernel_100ns_delta'] + counters['user_100ns_delta']) / 10**7)
for key in fixed:
    cells = [s for s in samples if (s['pair'], s['phase']) == key]
    assert len(cells) == 4 and len({s['result_fingerprint'] for s in cells}) == 1
    assert len({tuple(s['worker'][k] for k in ('input_tokens', 'reused_input_tokens', 'output_tokens')) for s in cells}) == 1
a, b = [s for s in samples if s['mode'] == 'default'], [s for s in samples if s['mode'] == 'blocktime0']
totals = {name: sum(values) for name, values in idle.items()}
baseline, treatment = totals['A1'] + totals['A2'], totals['B1'] + totals['B2']
assert baseline >= .6 and treatment <= .25 * baseline
assert max(totals['B1'], totals['B2']) <= .25 * min(totals['A1'], totals['A2'])
warm_a, warm_b = [statistics.median(s['first_seconds'] for s in group if s['phase'] == 'warm') for group in (a, b)]
assert warm_b <= 1.1 * warm_a
assert max(s['worker']['phases']['prefill_seconds'] for s in b) <= 1.1 * max(s['worker']['phases']['prefill_seconds'] for s in a)
assert r['network_audit']['status'] == 'PASS' and r['network_audit']['complete_cohort_and_cleanup'] is True
assert not r['network_audit']['worker_events'] and r['s06']['worker_absent'] is True
wfp = json.loads((report.parent / 's06-governed-diagnostic-wfp.json').read_bytes())
assert wfp['probe_denied'] is True and wfp['audit_enabled'] is True
assert set(r['network_audit']['worker_pids']) == set(r['worker_pids'])
assert not any(event['pid'] in r['worker_pids'] for event in wfp['events'])
proof = {'schema': 'provelume-independent-prospective-cost-proof/v1', 'result': 'DEMONSTRATED',
         'scope': 'avoidable native idle CPU; not historical cause or final source qualification',
         'experiment_head': r['source_commit'], 'run_id': 39845510739, 'run_attempt': 1,
         'job_id': 120057608187, 'artifact_id': 12454944310,
         'complete_cells': 24, 'self_tests': 15, 'preceding_corpus_samples': 60,
         'block_idle_cpu_seconds': totals, 'baseline_idle_cpu_seconds': baseline,
         'treatment_idle_cpu_seconds': treatment, 'warm_first_medians': [warm_a, warm_b],
         'selected_cpu_topology': topology, 'historical_cause': 'UNPROVEN',
         'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
         'artifact_sha256': hashlib.sha256((root / 'raw/artifact12454944310.zip').read_bytes()).hexdigest()}
print(json.dumps(proof, indent=2))
